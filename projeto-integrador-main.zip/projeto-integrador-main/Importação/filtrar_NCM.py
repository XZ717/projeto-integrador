import pandas as pd
import csv

# Caminho do arquivo original
file_path = "Importação/NCM.csv"

# Detecta automaticamente o delimitador
with open(file_path, "r", encoding="latin1") as f:
    sample = f.read(2000)
    dialect = csv.Sniffer().sniff(sample)

# Carrega o arquivo com o delimitador correto
df = pd.read_csv(file_path, dtype=str, encoding="latin1", delimiter=dialect.delimiter)

# Filtra as linhas onde CO_SH6 começa com 8802 ou 9301
filtros = df[df["CO_SH6"].str.startswith(("8802", "9301"), na=False)]

# Salva o resultado em um novo arquivo
filtros.to_csv("NCM_filtrado.csv", index=False, encoding="latin1")

print("Arquivo salvo como NCM_filtrado.csv")
